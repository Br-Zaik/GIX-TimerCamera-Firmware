#include "M5TimerCAM.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <WebServer.h>
#include <Update.h>
#include <esp_system.h>

// ==========================================================
// GI X - TIMER CAMERA-X
// BRILLO ADAPTATIVO + QXGA + 4 FOTOS + OTA
//
// OBJETIVO:
// - Adaptarse automaticamente a lugares claros u oscuros.
// - Evitar fotos casi negras.
// - Mantener 4 fotos, aprox. 1 por segundo.
// - Conservar OTA para futuras actualizaciones sin PC.
// - Apagarse al terminar o si falla la conexion.
// ==========================================================

// -----------------------
// WIFI NORMAL
// -----------------------
const char* WIFI_NAME = "Ass";
const char* WIFI_PASSWORD = "vvvvvvvv";

// -----------------------
// GI X
// -----------------------
const char* GIX_TOKEN = "GIX2026CAM";
const uint16_t GIX_PORT = 8765;

// -----------------------
// FOTOS
// -----------------------
const uint8_t PHOTO_COUNT = 4;

// El sensor usa este tiempo para ajustar exposicion,
// ganancia y balance de blancos. Se hace mientras conecta Wi-Fi.
const uint32_t MIN_WARMUP_MS = 2500;

// Objetivo acordado: una foto cada ~1 segundo.
const uint32_t PHOTO_INTERVAL_MS = 1000;

// Calidad JPEG alta. En ESP32, menor = mas calidad.
// 8 mantiene mucho detalle sin disparar demasiado el tamaño.
const int JPEG_QUALITY = 8;

// -----------------------
// TIEMPOS
// -----------------------
const uint32_t WIFI_NORMAL_TIMEOUT_MS = 6500;
const uint32_t POLL_TIMEOUT_MS = 900;
const uint32_t HTTP_PHOTO_TIMEOUT_MS = 1600;
const uint8_t MAX_SEND_ATTEMPTS = 2;

// -----------------------
// OTA SIN PC
// -----------------------
// Para entrar a OTA:
// 1) Cambia temporalmente el hotspot del celular a:
//       GIX-OTA-TRIGGER
//    con contraseña:
//       vvvvvvvv
// 2) Enciende la camara.
// 3) La camara crea:
//       GIX-CAM-UPDATE
//    clave:
//       GIX2026OTA
// 4) Conectate y abre:
//       http://192.168.4.1
// 5) Sube el .bin nuevo.

const char* OTA_TRIGGER_SSID = "GIX-OTA-TRIGGER";
const char* OTA_TRIGGER_PASSWORD = "vvvvvvvv";
const char* OTA_AP_SSID = "GIX-CAM-UPDATE";
const char* OTA_AP_PASSWORD = "GIX2026OTA";
const uint32_t OTA_PORTAL_TIMEOUT_MS = 10UL * 60UL * 1000UL;

WebServer otaServer(80);

// ==========================================================
// MEMORIA DE FOTOS
// ==========================================================

struct StoredPhoto {
  uint8_t* data = nullptr;
  size_t len = 0;
  bool sent = false;
};

StoredPhoto photos[PHOTO_COUNT];

void clearPhoto(uint8_t index) {
  if (index >= PHOTO_COUNT) return;

  if (photos[index].data != nullptr) {
    free(photos[index].data);
    photos[index].data = nullptr;
  }

  photos[index].len = 0;
  photos[index].sent = false;
}

void clearAllPhotos() {
  for (uint8_t i = 0; i < PHOTO_COUNT; i++) {
    clearPhoto(i);
  }
}

// ==========================================================
// APAGADO
// ==========================================================

void shutdownCamera() {
  Serial.println();
  Serial.println("GI X: APAGANDO");

  TimerCAM.Power.setLed(0);

  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);

  clearAllPhotos();

  delay(120);

  TimerCAM.Power.powerOff();

  // Si esta alimentada por USB puede seguir ejecutando,
  // pero en bateria debe apagarse.
  while (true) {
    delay(1000);
  }
}

// ==========================================================
// SENSOR OV3660 - AJUSTE ADAPTATIVO DE LUZ
// ==========================================================

void configureCamera() {
  sensor_t* s = TimerCAM.Camera.sensor;

  // Maxima resolucion del sensor usada por el ejemplo
  // oficial para la variante de 3 MP.
  s->set_pixformat(s, PIXFORMAT_JPEG);
  s->set_framesize(s, FRAMESIZE_QXGA);
  s->set_quality(s, JPEG_QUALITY);

  // Imagen natural para documentos.
  // No forzamos contraste alto porque oscurece sombras.
  s->set_brightness(s, 1);
  s->set_contrast(s, 0);
  s->set_saturation(s, 0);

  // Nitidez moderada: mejora letras sin crear halos fuertes.
  s->set_sharpness(s, 1);
  s->set_denoise(s, 1);

  // AUTOEXPOSICION + AUTOGANANCIA.
  // Esto es lo principal para que se adapte a la luz.
  s->set_exposure_ctrl(s, 1);
  s->set_gain_ctrl(s, 1);

  // AEC2 ayuda en escenas con poca luz.
  s->set_aec2(s, 1);

  // Objetivo de exposicion ligeramente mas claro.
  // Rango habitual del driver: -2 ... +2.
  s->set_ae_level(s, 1);

  // Permite al sensor levantar bastante la imagen si hace falta.
  // Puede añadir ruido en lugares muy oscuros, pero evita negro.
  s->set_gainceiling(s, GAINCEILING_32X);

  // BALANCE DE BLANCOS AUTOMATICO.
  s->set_whitebal(s, 1);
  s->set_awb_gain(s, 1);
  s->set_wb_mode(s, 0);

  // Correcciones internas utiles para documentos.
  s->set_bpc(s, 1);
  s->set_wpc(s, 1);
  s->set_raw_gma(s, 1);
  s->set_lenc(s, 1);

  // Orientacion TimerCamera-X.
  s->set_vflip(s, 1);
  s->set_hmirror(s, 0);
}

// ==========================================================
// DESCARTAR FRAME PARA QUE AEC/AWB SE ACOMODEN
// ==========================================================

void discardFrame() {
  if (TimerCAM.Camera.get()) {
    TimerCAM.Camera.free();
  }
}

// ==========================================================
// WIFI NORMAL + CALENTAMIENTO DE CAMARA EN PARALELO
// ==========================================================

bool connectWifiAndWarmCamera() {
  WiFi.disconnect(true);
  delay(50);

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_NAME, WIFI_PASSWORD);

  Serial.println("GI X: CONECTANDO A ASS + AJUSTANDO LUZ");

  const unsigned long start = millis();
  unsigned long lastDiscard = 0;

  while (millis() - start < WIFI_NORMAL_TIMEOUT_MS) {
    // Dar varios cuadros al algoritmo de autoexposicion y AWB.
    if (millis() - lastDiscard >= 120) {
      discardFrame();
      lastDiscard = millis();
    }

    const bool wifiReady = WiFi.status() == WL_CONNECTED;
    const bool warmupReady = millis() - start >= MIN_WARMUP_MS;

    if (wifiReady && warmupReady) {
      // Dos cuadros finales extra para que el cambio de exposicion
      // tenga tiempo de reflejarse antes de la primera foto real.
      discardFrame();
      delay(80);
      discardFrame();
      delay(80);

      Serial.println("GI X: WIFI + EXPOSICION LISTOS");
      Serial.print("IP CAMARA: ");
      Serial.println(WiFi.localIP());
      Serial.print("IP CELULAR: ");
      Serial.println(WiFi.gatewayIP());
      return true;
    }

    delay(5);
  }

  Serial.println("GI X: NO ENCONTRO ASS");
  return false;
}

// ==========================================================
// ACTIVADOR OTA
// ==========================================================

bool otaTriggerAvailable() {
  WiFi.disconnect(true);
  delay(60);

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(OTA_TRIGGER_SSID, OTA_TRIGGER_PASSWORD);

  const unsigned long start = millis();

  while (millis() - start < 1800) {
    if (WiFi.status() == WL_CONNECTED) {
      WiFi.disconnect(true);
      delay(80);
      return true;
    }
    delay(25);
  }

  WiFi.disconnect(true);
  return false;
}

// ==========================================================
// PORTAL OTA
// ==========================================================

void startOtaPortal() {
  Serial.println();
  Serial.println("GI X: MODO OTA");

  WiFi.disconnect(true);
  delay(100);

  WiFi.mode(WIFI_AP);

  if (!WiFi.softAP(OTA_AP_SSID, OTA_AP_PASSWORD)) {
    Serial.println("ERROR CREANDO AP OTA");
    shutdownCamera();
  }

  // LED azul SOLO en OTA.
  TimerCAM.Power.setLed(120);

  otaServer.on("/", HTTP_GET, []() {
    const char* page =
      "<!doctype html>"
      "<html><head>"
      "<meta name='viewport' content='width=device-width,initial-scale=1'>"
      "<title>GI X Camera</title>"
      "</head>"
      "<body style='font-family:Arial;max-width:520px;margin:30px auto;padding:20px'>"
      "<h2>GI X - Actualizar camara</h2>"
      "<p>Selecciona el firmware .bin nuevo.</p>"
      "<form method='POST' action='/update' enctype='multipart/form-data'>"
      "<input type='file' name='firmware' accept='.bin' required>"
      "<br><br>"
      "<button type='submit' style='font-size:20px;padding:12px'>ACTUALIZAR</button>"
      "</form>"
      "</body></html>";

    otaServer.send(200, "text/html", page);
  });

  otaServer.on(
    "/update",
    HTTP_POST,
    []() {
      const bool ok = !Update.hasError();

      otaServer.sendHeader("Connection", "close");
      otaServer.send(
        ok ? 200 : 500,
        "text/plain",
        ok ? "Firmware actualizado. Reiniciando..." : "ERROR al actualizar."
      );

      delay(1000);

      if (ok) {
        ESP.restart();
      }
    },
    []() {
      HTTPUpload& upload = otaServer.upload();

      if (upload.status == UPLOAD_FILE_START) {
        Serial.printf("OTA: %s\n", upload.filename.c_str());

        if (!Update.begin(UPDATE_SIZE_UNKNOWN)) {
          Update.printError(Serial);
        }
      }
      else if (upload.status == UPLOAD_FILE_WRITE) {
        const size_t written = Update.write(upload.buf, upload.currentSize);

        if (written != upload.currentSize) {
          Update.printError(Serial);
        }
      }
      else if (upload.status == UPLOAD_FILE_END) {
        if (!Update.end(true)) {
          Update.printError(Serial);
        }
      }
      else if (upload.status == UPLOAD_FILE_ABORTED) {
        Update.end();
      }
    }
  );

  otaServer.begin();

  Serial.println("Wi-Fi OTA: GIX-CAM-UPDATE");
  Serial.println("Clave OTA: GIX2026OTA");
  Serial.println("Abrir: http://192.168.4.1");

  const unsigned long start = millis();

  while (millis() - start < OTA_PORTAL_TIMEOUT_MS) {
    otaServer.handleClient();
    delay(2);
  }

  otaServer.stop();
  WiFi.softAPdisconnect(true);
  shutdownCamera();
}

// ==========================================================
// GI X
// ==========================================================

String gixBaseUrl() {
  return String("http://") +
         WiFi.gatewayIP().toString() +
         ":" +
         String(GIX_PORT);
}

String getBatchId() {
  HTTPClient http;
  http.setTimeout(POLL_TIMEOUT_MS);

  const String url =
    gixBaseUrl() +
    "/camera/poll?token=" +
    String(GIX_TOKEN);

  http.begin(url);

  const int code = http.GET();
  String id = "";

  if (code >= 200 && code < 300) {
    String body = http.getString();
    body.trim();

    if (body.startsWith("CAPTURE|")) {
      id = body.substring(8);
      id.trim();
    }
  }

  http.end();

  if (id.length() == 0) {
    id =
      "GIX-" +
      String((uint32_t)esp_random(), HEX);
  }

  Serial.print("LOTE: ");
  Serial.println(id);

  return id;
}

// ==========================================================
// CAPTURA
// ==========================================================

bool capturePhoto(uint8_t index) {
  if (index >= PHOTO_COUNT) return false;

  if (!TimerCAM.Camera.get()) {
    Serial.printf("FOTO %u: ERROR CAPTURA\n", index + 1);
    return false;
  }

  if (TimerCAM.Camera.fb == nullptr ||
      TimerCAM.Camera.fb->buf == nullptr ||
      TimerCAM.Camera.fb->len == 0) {

    TimerCAM.Camera.free();
    return false;
  }

  const size_t len = TimerCAM.Camera.fb->len;

  uint8_t* copy = (uint8_t*)ps_malloc(len);

  if (copy == nullptr) {
    Serial.printf("FOTO %u: SIN PSRAM\n", index + 1);
    TimerCAM.Camera.free();
    return false;
  }

  memcpy(copy, TimerCAM.Camera.fb->buf, len);
  TimerCAM.Camera.free();

  photos[index].data = copy;
  photos[index].len = len;
  photos[index].sent = false;

  Serial.printf(
    "FOTO %u/4 CAPTURADA - %u bytes\n",
    index + 1,
    (unsigned int)len
  );

  return true;
}

// ==========================================================
// ENVIO
// ==========================================================

bool sendPhotoOnce(uint8_t index, const String& batchId) {
  if (index >= PHOTO_COUNT ||
      photos[index].data == nullptr ||
      photos[index].len == 0) {
    return false;
  }

  if (WiFi.status() != WL_CONNECTED) {
    return false;
  }

  const String url =
    gixBaseUrl() +
    "/camera/photo?token=" +
    String(GIX_TOKEN) +
    "&requestId=" +
    batchId +
    "&part=" +
    String(index + 1) +
    "&total=" +
    String(PHOTO_COUNT);

  HTTPClient http;
  http.setTimeout(HTTP_PHOTO_TIMEOUT_MS);
  http.begin(url);
  http.addHeader("Content-Type", "image/jpeg");
  http.addHeader("Connection", "close");

  const int code =
    http.POST(
      photos[index].data,
      photos[index].len
    );

  const bool success =
    code >= 200 && code < 300;

  Serial.printf(
    success
      ? "FOTO %u/4 ENVIADA - HTTP %d\n"
      : "FOTO %u/4 FALLO - HTTP %d\n",
    index + 1,
    code
  );

  http.end();
  return success;
}

uint8_t sendAllPhotos(const String& batchId) {
  uint8_t sentCount = 0;

  // Primera pasada: siempre intenta las 4.
  for (uint8_t i = 0; i < PHOTO_COUNT; i++) {
    if (photos[i].data == nullptr) continue;

    if (sendPhotoOnce(i, batchId)) {
      photos[i].sent = true;
      sentCount++;

      free(photos[i].data);
      photos[i].data = nullptr;
      photos[i].len = 0;
    }
  }

  // Segunda pasada: solo las que fallaron.
  for (uint8_t i = 0; i < PHOTO_COUNT; i++) {
    if (photos[i].sent || photos[i].data == nullptr) continue;

    Serial.printf("SEGUNDO INTENTO FOTO %u\n", i + 1);

    if (sendPhotoOnce(i, batchId)) {
      photos[i].sent = true;
      sentCount++;

      free(photos[i].data);
      photos[i].data = nullptr;
      photos[i].len = 0;
    }
  }

  return sentCount;
}

// ==========================================================
// SETUP
// ==========================================================

void setup() {
  Serial.begin(115200);
  delay(180);

  TimerCAM.begin();
  TimerCAM.Power.begin();

  // LED apagado en uso normal.
  TimerCAM.Power.setLed(0);

  clearAllPhotos();

  Serial.println();
  Serial.println("====================================");
  Serial.println("GI X CAMERA - BRILLO ADAPTATIVO");
  Serial.println("QXGA / 4 FOTOS / ~1 SEGUNDO");
  Serial.println("====================================");

  if (!TimerCAM.Camera.begin()) {
    Serial.println("ERROR INICIANDO OV3660");
    shutdownCamera();
  }

  configureCamera();

  const bool wifiReady =
    connectWifiAndWarmCamera();

  if (!wifiReady) {
    // OTA solo cuando el usuario lo activa expresamente.
    if (otaTriggerAvailable()) {
      startOtaPortal();
    }

    shutdownCamera();
  }

  const String batchId =
    getBatchId();

  // Tomar 4 fotos aprox. cada 1 segundo.
  const unsigned long sequenceStart =
    millis();

  uint8_t captured = 0;

  for (uint8_t i = 0; i < PHOTO_COUNT; i++) {
    const unsigned long target =
      sequenceStart +
      ((uint32_t)i * PHOTO_INTERVAL_MS);

    while ((long)(millis() - target) < 0) {
      delay(2);
    }

    if (capturePhoto(i)) {
      captured++;
    }
  }

  Serial.printf(
    "CAPTURADAS: %u/4\n",
    captured
  );

  const uint8_t sent =
    sendAllPhotos(batchId);

  Serial.printf(
    "ENVIADAS: %u/4\n",
    sent
  );

  delay(150);
  shutdownCamera();
}

void loop() {
  delay(1000);
}
