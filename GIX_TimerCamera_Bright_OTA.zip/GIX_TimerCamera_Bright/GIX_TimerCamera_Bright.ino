#include "M5TimerCAM.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <WebServer.h>
#include <Update.h>
#include <esp_system.h>

// ==========================================================
// GI X - TimerCamera-X - PERFIL CLARO v4
//
// OBJETIVO:
// - Volver al perfil de imagen claro y estable de TimerCamera-X.
// - Usar la resolución alta ESTABLE documentada por M5Stack: UXGA 1600x1200.
// - Mantener autoexposición / autoganancia / AWB.
// - Brillo +1 y saturación -2, ajuste clásico usado en ejemplos ESP32-CAM.
// - 4 fotos, objetivo ~1 segundo entre capturas.
// - OTA por Wi-Fi durante solo 2 minutos.
// - LED azul únicamente durante OTA.
// - Apagado automático al terminar.
// ==========================================================

// -----------------------
// WIFI NORMAL
// -----------------------
const char* WIFI_NAME = "Ass";
const char* WIFI_PASSWORD = "vvvvvvvv";

// -----------------------
// GI X
// -----------------------
const char* GIX_TOKEN = "GIX2026CAM";
const uint16_t GIX_PORT = 8765;

// -----------------------
// FOTOS
// -----------------------
const uint8_t PHOTO_COUNT = 4;
const uint32_t PHOTO_INTERVAL_MS = 1000;

// UXGA 1600x1200: resolución alta y estable para TimerCamera-X.
// Calidad JPEG: menor valor = más calidad.
const framesize_t FINAL_FRAME_SIZE = FRAMESIZE_UXGA;
const int JPEG_QUALITY = 8;

// Dar tiempo real al AEC/AGC/AWB para adaptarse.
const uint32_t MIN_WARMUP_MS = 3000;
const uint8_t MIN_WARMUP_FRAMES = 8;

// -----------------------
// RED / ENVIO
// -----------------------
const uint32_t WIFI_TIMEOUT_MS = 7000;
const uint32_t POLL_TIMEOUT_MS = 900;
const uint32_t HTTP_PHOTO_TIMEOUT_MS = 1800;
const uint8_t SEND_PASSES = 2;

// -----------------------
// OTA
// -----------------------
// Hotspot temporal:
//   GIX-OTA-TRIGGER
// Clave:
//   vvvvvvvv
//
// La cámara crea:
//   GIX-CAM-UPDATE
// Clave:
//   GIX2026OTA
//
// Abrir:
//   http://192.168.4.1
//
// El OTA dura SOLO 2 MINUTOS.
const char* OTA_TRIGGER_SSID = "GIX-OTA-TRIGGER";
const char* OTA_TRIGGER_PASSWORD = "vvvvvvvv";

const char* OTA_AP_SSID = "GIX-CAM-UPDATE";
const char* OTA_AP_PASSWORD = "GIX2026OTA";

const uint32_t OTA_PORTAL_TIMEOUT_MS = 2UL * 60UL * 1000UL;

WebServer otaServer(80);

// ==========================================================
// MEMORIA
// ==========================================================

struct StoredPhoto {
  uint8_t* data = nullptr;
  size_t len = 0;
  bool sent = false;
};

StoredPhoto photos[PHOTO_COUNT];

void clearPhoto(uint8_t i) {
  if (i >= PHOTO_COUNT) return;

  if (photos[i].data != nullptr) {
    free(photos[i].data);
    photos[i].data = nullptr;
  }

  photos[i].len = 0;
  photos[i].sent = false;
}

void clearAllPhotos() {
  for (uint8_t i = 0; i < PHOTO_COUNT; i++) {
    clearPhoto(i);
  }
}

// ==========================================================
// APAGADO
// ==========================================================

void shutdownCamera() {
  Serial.println("GI X: APAGANDO");

  TimerCAM.Power.setLed(0);

  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);

  clearAllPhotos();

  delay(120);

  TimerCAM.Power.powerOff();

  // Con USB puede seguir alimentada físicamente.
  while (true) {
    delay(1000);
  }
}

// ==========================================================
// CONFIGURACIÓN DE CÁMARA
// ==========================================================

void configureCamera() {
  sensor_t* s = TimerCAM.Camera.sensor;

  // JPEG + resolución alta estable.
  s->set_pixformat(s, PIXFORMAT_JPEG);
  s->set_framesize(s, FINAL_FRAME_SIZE);
  s->set_quality(s, JPEG_QUALITY);

  // Mantener exposición, ganancia y balance automáticos.
  s->set_exposure_ctrl(s, 1);
  s->set_gain_ctrl(s, 1);
  s->set_whitebal(s, 1);
  s->set_awb_gain(s, 1);

  // Perfil claro clásico de ESP32-CAM:
  // un poco más de brillo y menos saturación.
  s->set_brightness(s, 1);
  s->set_saturation(s, -2);

  // NO tocamos:
  // - ae_level
  // - aec2
  // - gain ceiling
  // - exposición manual
  // - ganancia manual
  // - contraste agresivo
  // - sharpness agresivo

  s->set_vflip(s, 1);
  s->set_hmirror(s, 0);
}

bool discardFrame() {
  if (!TimerCAM.Camera.get()) {
    return false;
  }

  TimerCAM.Camera.free();
  return true;
}

// ==========================================================
// WIFI + ESTABILIZACIÓN DE EXPOSICIÓN
// ==========================================================

bool connectWifiAndWarmup() {
  WiFi.disconnect(true);
  delay(50);

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_NAME, WIFI_PASSWORD);

  const unsigned long start = millis();
  uint8_t frames = 0;

  while (millis() - start < WIFI_TIMEOUT_MS) {
    if (frames < MIN_WARMUP_FRAMES) {
      if (discardFrame()) {
        frames++;
      }
    }

    const bool wifiReady = WiFi.status() == WL_CONNECTED;
    const bool timeReady = millis() - start >= MIN_WARMUP_MS;
    const bool framesReady = frames >= MIN_WARMUP_FRAMES;

    if (wifiReady && timeReady && framesReady) {
      // Dos frames finales antes de la primera foto real.
      discardFrame();
      delay(100);
      discardFrame();
      delay(100);

      Serial.println("GI X: WIFI + CAMARA LISTOS");
      return true;
    }

    delay(5);
  }

  return false;
}

// ==========================================================
// DETECTAR OTA
// ==========================================================

bool otaTriggerAvailable() {
  WiFi.disconnect(true);
  delay(60);

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(OTA_TRIGGER_SSID, OTA_TRIGGER_PASSWORD);

  const unsigned long start = millis();

  while (millis() - start < 1800) {
    if (WiFi.status() == WL_CONNECTED) {
      WiFi.disconnect(true);
      delay(80);
      return true;
    }

    delay(25);
  }

  WiFi.disconnect(true);
  return false;
}

// ==========================================================
// PORTAL OTA
// ==========================================================

void startOtaPortal() {
  WiFi.disconnect(true);
  delay(100);

  WiFi.mode(WIFI_AP);

  if (!WiFi.softAP(OTA_AP_SSID, OTA_AP_PASSWORD)) {
    shutdownCamera();
  }

  // Azul SOLO durante OTA.
  TimerCAM.Power.setLed(120);

  otaServer.on("/", HTTP_GET, []() {
    const char* page =
      "<!doctype html>"
      "<html><head>"
      "<meta name='viewport' content='width=device-width,initial-scale=1'>"
      "<title>GI X Camera</title>"
      "</head>"
      "<body style='font-family:Arial;max-width:520px;margin:30px auto;padding:20px'>"
      "<h2>GI X - Actualizar camara</h2>"
      "<p>Selecciona el firmware .bin nuevo.</p>"
      "<p>El modo OTA se cierra en 2 minutos.</p>"
      "<form method='POST' action='/update' enctype='multipart/form-data'>"
      "<input type='file' name='firmware' accept='.bin' required>"
      "<br><br>"
      "<button type='submit' style='font-size:20px;padding:12px'>ACTUALIZAR</button>"
      "</form>"
      "</body></html>";

    otaServer.send(200, "text/html", page);
  });

  otaServer.on(
    "/update",
    HTTP_POST,
    []() {
      const bool ok = !Update.hasError();

      otaServer.sendHeader("Connection", "close");
      otaServer.send(
        ok ? 200 : 500,
        "text/plain",
        ok
          ? "Firmware actualizado. La camara se apagara."
          : "ERROR al actualizar. Intenta de nuevo."
      );

      if (ok) {
        delay(1500);
        shutdownCamera();
      }
    },
    []() {
      HTTPUpload& up = otaServer.upload();

      if (up.status == UPLOAD_FILE_START) {
        if (!Update.begin(UPDATE_SIZE_UNKNOWN)) {
          Update.printError(Serial);
        }
      }
      else if (up.status == UPLOAD_FILE_WRITE) {
        if (Update.write(up.buf, up.currentSize) != up.currentSize) {
          Update.printError(Serial);
        }
      }
      else if (up.status == UPLOAD_FILE_END) {
        if (!Update.end(true)) {
          Update.printError(Serial);
        }
      }
      else if (up.status == UPLOAD_FILE_ABORTED) {
        Update.end();
      }
    }
  );

  otaServer.begin();

  const unsigned long start = millis();

  while (millis() - start < OTA_PORTAL_TIMEOUT_MS) {
    otaServer.handleClient();
    delay(2);
  }

  otaServer.stop();
  WiFi.softAPdisconnect(true);

  TimerCAM.Power.setLed(0);
  shutdownCamera();
}

// ==========================================================
// GI X
// ==========================================================

String gixBaseUrl() {
  return String("http://") +
         WiFi.gatewayIP().toString() +
         ":" +
         String(GIX_PORT);
}

String getBatchId() {
  HTTPClient http;
  http.setTimeout(POLL_TIMEOUT_MS);

  const String url =
    gixBaseUrl() +
    "/camera/poll?token=" +
    String(GIX_TOKEN);

  http.begin(url);

  const int code = http.GET();
  String id = "";

  if (code >= 200 && code < 300) {
    String body = http.getString();
    body.trim();

    if (body.startsWith("CAPTURE|")) {
      id = body.substring(8);
      id.trim();
    }
  }

  http.end();

  if (id.length() == 0) {
    id = "GIX-" + String((uint32_t)esp_random(), HEX);
  }

  return id;
}

// ==========================================================
// CAPTURA
// ==========================================================

bool capturePhoto(uint8_t i) {
  if (i >= PHOTO_COUNT) return false;

  if (!TimerCAM.Camera.get()) {
    Serial.printf("FOTO %u: ERROR CAPTURA\n", i + 1);
    return false;
  }

  if (TimerCAM.Camera.fb == nullptr ||
      TimerCAM.Camera.fb->buf == nullptr ||
      TimerCAM.Camera.fb->len == 0) {
    TimerCAM.Camera.free();
    return false;
  }

  const size_t len = TimerCAM.Camera.fb->len;

  uint8_t* copy = (uint8_t*)ps_malloc(len);

  if (copy == nullptr) {
    TimerCAM.Camera.free();
    return false;
  }

  memcpy(copy, TimerCAM.Camera.fb->buf, len);
  TimerCAM.Camera.free();

  photos[i].data = copy;
  photos[i].len = len;
  photos[i].sent = false;

  Serial.printf(
    "FOTO %u/4 CAPTURADA - %u bytes\n",
    i + 1,
    (unsigned int)len
  );

  return true;
}

// ==========================================================
// ENVÍO
// ==========================================================

bool sendPhotoOnce(uint8_t i, const String& batchId) {
  if (i >= PHOTO_COUNT ||
      photos[i].data == nullptr ||
      photos[i].len == 0) {
    return false;
  }

  if (WiFi.status() != WL_CONNECTED) {
    return false;
  }

  const String url =
    gixBaseUrl() +
    "/camera/photo?token=" +
    String(GIX_TOKEN) +
    "&requestId=" +
    batchId;

  HTTPClient http;
  http.setTimeout(HTTP_PHOTO_TIMEOUT_MS);
  http.begin(url);

  http.addHeader("Content-Type", "image/jpeg");
  http.addHeader("Connection", "close");

  const int code =
    http.POST(
      photos[i].data,
      photos[i].len
    );

  const bool ok =
    code >= 200 &&
    code < 300;

  Serial.printf(
    ok
      ? "FOTO %u/4 ENVIADA - HTTP %d\n"
      : "FOTO %u/4 FALLO - HTTP %d\n",
    i + 1,
    code
  );

  http.end();

  return ok;
}

uint8_t sendAllPhotos(const String& batchId) {
  uint8_t sent = 0;

  // Dos pasadas.
  // Una foto fallida NO cancela las demás.
  for (uint8_t pass = 0; pass < SEND_PASSES; pass++) {
    for (uint8_t i = 0; i < PHOTO_COUNT; i++) {
      if (photos[i].sent || photos[i].data == nullptr) {
        continue;
      }

      if (sendPhotoOnce(i, batchId)) {
        photos[i].sent = true;
        sent++;

        free(photos[i].data);
        photos[i].data = nullptr;
        photos[i].len = 0;
      }
    }
  }

  return sent;
}

// ==========================================================
// SETUP
// ==========================================================

void setup() {
  Serial.begin(115200);
  delay(180);

  TimerCAM.begin();
  TimerCAM.Power.begin();

  // Uso normal = LED apagado.
  TimerCAM.Power.setLed(0);

  clearAllPhotos();

  if (!TimerCAM.Camera.begin()) {
    shutdownCamera();
  }

  configureCamera();

  if (!connectWifiAndWarmup()) {
    // OTA solo cuando TU hotspot se llama GIX-OTA-TRIGGER.
    if (otaTriggerAvailable()) {
      startOtaPortal();
    }

    shutdownCamera();
  }

  const String batchId = getBatchId();

  const unsigned long sequenceStart = millis();

  uint8_t captured = 0;

  for (uint8_t i = 0; i < PHOTO_COUNT; i++) {
    const unsigned long target =
      sequenceStart +
      ((uint32_t)i * PHOTO_INTERVAL_MS);

    while ((long)(millis() - target) < 0) {
      delay(2);
    }

    if (capturePhoto(i)) {
      captured++;
    }
  }

  Serial.printf("CAPTURADAS: %u/4\n", captured);

  const uint8_t sent =
    sendAllPhotos(batchId);

  Serial.printf("ENVIADAS: %u/4\n", sent);

  delay(150);

  shutdownCamera();
}

void loop() {
  delay(1000);
}
